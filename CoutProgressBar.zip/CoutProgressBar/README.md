# CoutProgressBar
![](coutgif.gif)

Use Easily :)

Declare A Private Variable In Activity Or Fragment Or etc
```java
private CoutProgressBar coutProgressBar;
```
In Constructor Or onCreateView Or etc :
```java
coutProgressBar = new CoutProgressBar(your_root_layout , context);
```
For Show :
```java
coutProgressBar.show();
```
For Hide :
```java
coutProgressBar.dismis();
```
